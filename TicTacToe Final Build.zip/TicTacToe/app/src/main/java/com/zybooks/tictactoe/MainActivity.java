// Garrick Morley
// ISYS 221-001
// Assignment #4 - Tic Tac Toe
// Due: 10/03/2021

// This lets us move data across classes
package com.zybooks.tictactoe;

// Import all of the necessary packages
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements OnClickListener{

    // This creates all of the button objects
    Button button1;
    Button button2;
    Button button3;
    Button button4;
    Button button5;
    Button button6;
    Button button7;
    Button button8;
    Button button9;

    // This links the info button using the "view" import
    TextView info;

    //This creates the button object for a new game
    Button newGame;

    // This creates the two players, player "X" and player "O"
    int player_O = 0;
    int player_X = 1;


    // This is where we set the active player, which will initially be player "O"
    int playerUp = player_O;

    // This creates the array to hold all of the button values
    int[] fillPositions = {-1, -1, -1, -1 ,-1, -1, -1, -1, -1};

    // This boolean function checks to see if the game is active
    boolean isGameActive = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // This runs this code when the app is initially created
        super.onCreate(savedInstanceState);

        // This runs our code in addition to the existing code
        setContentView(R.layout.activity_main);

        // Initially set the turn to player "O" on the screen
        info = findViewById(R.id.infoLabel);
        info.setText("Player 0's turn");

        // This sets each button to its corresponding value in the .xml file
        button1 = findViewById(R.id.square1);
        button2 = findViewById(R.id.square2);
        button3 = findViewById(R.id.square3);
        button4 = findViewById(R.id.square4);
        button5 = findViewById(R.id.square5);
        button6 = findViewById(R.id.square6);
        button7 = findViewById(R.id.square7);
        button8 = findViewById(R.id.square8);
        button9 = findViewById(R.id.square9);

        // This sets the newGame function to the corresponding button in the .xml file
        newGame = findViewById(R.id.newgame_id);

        // This utilizes the "this" keyword to point to each button
        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
        button3.setOnClickListener(this);
        button4.setOnClickListener(this);
        button5.setOnClickListener(this);
        button6.setOnClickListener(this);
        button7.setOnClickListener(this);
        button8.setOnClickListener(this);
        button9.setOnClickListener(this);

        // Sets the newGame function to activate when then corresponding button is clicked
        newGame.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                newGame();
            }
        });

    }

    // This function starts a new game when clicked
    private void newGame() {

        // Start on player "O" and display that fact
        playerUp = player_O;
        info.setText("Player O's turn");

        // Create and fill an array to hold potential values
        fillPositions = new int[]{-1, -1, -1, -1 ,-1, -1, -1, -1, -1};

        // Create and set each button to a blank interface
        button1.setText("");
        button2.setText("");
        button3.setText("");
        button4.setText("");
        button5.setText("");
        button6.setText("");
        button7.setText("");
        button8.setText("");
        button9.setText("");

        // Set the "isGameActive" boolean value to true
        isGameActive = true;

    }

    @Override
    // This checks to make sure the game is active
    public void onClick(View v) {

        if(!isGameActive)
            return;

        // This detects who's turn it is
        Button clickedSquare = findViewById(v.getId());

        // This creates the integer variable "clickedTag" and retrieves the string value for it
        int clickedTag = Integer.parseInt(v.getTag().toString());

        // This fills the positions when clicked
        if(fillPositions[clickedTag] != -1)
        {
            return;
        }

        // This links the filled positions to the active player
        fillPositions[clickedTag] = playerUp;

        if(playerUp == player_O)
        {
            clickedSquare.setText("O");
            playerUp = player_X;
            info.setText("Player X's turn");
        }
        else
        {
            clickedSquare.setText("X");
            playerUp = player_O;
            info.setText("Player 0's turn");
        }

        // This calls the function to find the winning player
        findWinner();
    }

    private void findWinner() {
    // This class will store the possible winning positions in the array
        int[][] winners = {{0,1,2}, {3,4,5},{6,7,8}, {0,3,6}, {1,4,7}, {2,5,8}, {0,4,8}, {2,4,6}};


        for(int x = 0; x < 8; x++)
        {
            int zip = winners[x][0];
            int two = winners[x][1];
            int three = winners[x][2];

            if(fillPositions[zip] == fillPositions[two] && fillPositions[two] == fillPositions[three])
            {
                if(fillPositions[zip] != -1)
                {
                    // This is where the winner is declared
                    isGameActive = false;

                    if(fillPositions[zip] == player_O)
                    {
                        info.setText("Player 'O' has won");
                    }
                    else if(fillPositions[zip] == player_X)
                    {
                        info.setText("Player 'X' has won");
                    }
                    else if((fillPositions[zip] != player_X) && (fillPositions[zip] != player_O))
                    {
                        info.setText("Draw / CAT");
                    }
                }
            }
        }
    }
}